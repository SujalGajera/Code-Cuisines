import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBZHpFWX2AQxsB7ib777pNxh_3QTJJm3Kg",
  authDomain: "codecuisinefb.firebaseapp.com",
  projectId: "codecuisinefb",
  storageBucket: "codecuisinefb.firebasestorage.app",
  messagingSenderId: "825079536627",
  appId: "1:825079536627:web:96a87fb3b30c8318a95086"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
