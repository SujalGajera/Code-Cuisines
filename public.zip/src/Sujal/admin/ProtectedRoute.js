import React from "react";
import { Navigate, Outlet } from "react-router-dom";

export default function ProtectedRoute({ requireAdmin }) {
  const isAdminVerified = localStorage.getItem("isAdminVerified") === "true";

  if (requireAdmin && !isAdminVerified) {
    return <Navigate to="/login/admin" replace />;
  }

  return <Outlet />;
}
